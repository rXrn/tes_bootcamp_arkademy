<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_products extends CI_Model {
	public function all() {
		//ambil database
		$hasil = $this->db->get('hasil_data'); //nama table
		if($hasil->num_rows()>0) {
			return $hasil->result();
		} else {
			return array();
		}
	}

	public function find($id)
	{
		$hasil = $this->db->where('id', $id)
							->limit(1)
							->get('hasil_data');
		if($hasil->num_rows()>0) {
			return $hasil->row();
		} else {
			return array();
		}
	}

	public function create($data_products)
	{
		$this->db->insert('hasil_data', $data_products);
	}

	public function update($id, $data_products)
	{
		$this->db->where('id',$id)
					->update('hasil_data', $data_products);
	}

	public function delete($id)
	{
		$this->db->where('id', $id)
					->delete('hasil_data');
	}
}