<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends CI_Controller {

	public function __construct()
        {
                parent::__construct();
                // Your own constructor code
                $this->load->model('model_products');
        }

	public function index()
	{
		$data['hasil_data'] = $this->model_products->all();
		$this->load->view('backend/view_all_products', $data);
	}

	public function create()
	{
		$this->form_validation->set_rules('category_name', 'Category Name', 'required');
		$this->form_validation->set_rules('product_name', 'Product Name', 'required');
		

		if ($this->form_validation->run() == FALSE)
                {
                        $this->load->view('backend/form_tambah_product');
                }
                else
                {
                	$data_products = array (
                		'category_name'		=> set_value('category_name'), 
                		'product_name'	        => set_value('product_name')
                	);
                        $this->model_products->create($data_products);
                        redirect('admin/products');
                }
	}
	
	public function update($id)
	{
		$this->form_validation->set_rules('category_name', 'Category Name', 'required');
		$this->form_validation->set_rules('product_name', 'Product Name', 'required');

		if ($this->form_validation->run() == FALSE)
                {
                		$data['hasil_data'] = $this->model_products->find($id);
                                $this->load->view('backend/form_edit_product', $data);
                }
                else
                {
                	$data_products = array (
                		'category_name'		=> set_value('category_name'), 
                		'product_name'	        => set_value('product_name'),
                	);
                        $this->model_products->update($id, $data_products);
                        redirect('admin/products');
                }
	}

	public function delete($id)
	{
		$this->model_products->delete($id);
		redirect('admin/products');
	}
}
